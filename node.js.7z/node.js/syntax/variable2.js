var letter = 'Lorem ipsum dolor sit amet'

console.log(letter);