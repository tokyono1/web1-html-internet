var arr = ['A', 'B', 'C', 'D'];

console.log(arr[0]);
console.log(arr[1]);
console.log(arr[2]);
console.log(arr[3]);

arr[2] = '3';

arr.push("Z");

console.log(arr);

console.log(arr.length)
