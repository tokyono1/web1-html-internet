console.log('A');
console.log('B');
for(var i=0;i<10;i++) {
    console.log('C1');	
}
console.log('C2');
console.log('D');