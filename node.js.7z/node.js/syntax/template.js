var name = 'k8805';

var letter = 'Dear ${name} Lorem ipsum dolor sint amet';

console.log(letter);