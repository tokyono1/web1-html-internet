function sum(first, second){
	return (first + second);
}

console.log(sum(2,4));

console.log(Math.round(1.6));
console.log(Math.round(1.4));

filewrite('result.txt', Math.round(1.6));