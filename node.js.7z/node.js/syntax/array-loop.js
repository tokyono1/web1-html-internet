var arr = [1, 400, 12, 34, 5, 10000];
var sum = 0
for(var i = 0; i < arr.length; i++){
	sum = sum + arr[i];
}

console.log(sum);